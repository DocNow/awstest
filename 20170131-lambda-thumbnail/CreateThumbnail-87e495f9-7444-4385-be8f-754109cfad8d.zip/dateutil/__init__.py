# -*- coding: utf-8 -*-
__version__ = "2.6.0"
